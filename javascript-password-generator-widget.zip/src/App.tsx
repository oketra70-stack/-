import { useMemo, useState } from "react";

type PasswordOptions = {
  length: number;
  includeUppercase: boolean;
  includeNumbers: boolean;
  includeSymbols: boolean;
};

const CHARSET = {
  lowercase: "abcdefghijklmnopqrstuvwxyz",
  uppercase: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
  numbers: "0123456789",
  symbols: "!@#$%^&*()-_=+[]{};:,.?/",
};

function pickRandomChar(chars: string) {
  return chars[Math.floor(Math.random() * chars.length)];
}

function shuffleString(value: string) {
  const chars = value.split("");

  for (let i = chars.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }

  return chars.join("");
}

function generatePassword(options: PasswordOptions) {
  const groups: string[] = [CHARSET.lowercase];

  if (options.includeUppercase) groups.push(CHARSET.uppercase);
  if (options.includeNumbers) groups.push(CHARSET.numbers);
  if (options.includeSymbols) groups.push(CHARSET.symbols);

  const allChars = groups.join("");
  const guaranteed = groups.map((group) => pickRandomChar(group));
  const remainingLength = Math.max(options.length - guaranteed.length, 0);

  let password = guaranteed.join("");

  for (let i = 0; i < remainingLength; i += 1) {
    password += pickRandomChar(allChars);
  }

  return shuffleString(password);
}

function getStrengthScore(password: string) {
  const checks = [/[a-z]/, /[A-Z]/, /\d/, /[^A-Za-z0-9]/].reduce(
    (score, regex) => score + Number(regex.test(password)),
    0,
  );

  if (password.length >= 16 && checks >= 4) return { label: "Очень надежный", color: "bg-emerald-500" };
  if (password.length >= 12 && checks >= 3) return { label: "Надежный", color: "bg-lime-500" };
  if (password.length >= 10 && checks >= 2) return { label: "Средний", color: "bg-amber-500" };
  return { label: "Слабый", color: "bg-rose-500" };
}

export default function App() {
  const [options, setOptions] = useState<PasswordOptions>({
    length: 16,
    includeUppercase: true,
    includeNumbers: true,
    includeSymbols: true,
  });
  const [password, setPassword] = useState(() => generatePassword(options));
  const [copied, setCopied] = useState(false);

  const strength = useMemo(() => getStrengthScore(password), [password]);

  const handleGenerate = () => {
    setPassword(generatePassword(options));
    setCopied(false);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(password);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      setCopied(false);
    }
  };

  const strengthWidth =
    strength.label === "Очень надежный"
      ? "100%"
      : strength.label === "Надежный"
        ? "75%"
        : strength.label === "Средний"
          ? "50%"
          : "30%";

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-slate-950 px-6 py-10 text-slate-100">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top,_#3b82f680_0%,_transparent_50%),radial-gradient(circle_at_bottom,_#a21caf70_0%,_transparent_48%)]" />

      <section className="relative w-full max-w-xl rounded-3xl border border-white/20 bg-white/10 p-6 shadow-2xl shadow-black/40 backdrop-blur-xl sm:p-8">
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
          Генератор сложных паролей
        </h1>
        <p className="mt-2 text-sm text-slate-200/80 sm:text-base">
          Отдельный виджет для быстрого создания случайных и безопасных паролей.
        </p>

        <div className="mt-6 space-y-5">
          <div className="rounded-2xl bg-black/30 p-4">
            <div className="flex items-start justify-between gap-4">
              <code className="break-all pr-2 font-mono text-base leading-relaxed text-cyan-200 sm:text-lg">{password}</code>
              <button
                onClick={handleCopy}
                className="shrink-0 rounded-lg bg-cyan-400 px-3 py-2 text-xs font-semibold text-slate-950 transition hover:bg-cyan-300"
              >
                Копировать
              </button>
            </div>

            <div className="mt-3 flex items-center gap-3">
              <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
                <div
                  style={{ width: strengthWidth }}
                  className={`h-full transition-[width] duration-300 ${strength.color}`}
                />
              </div>
              <span className="text-xs text-slate-300">{strength.label}</span>
            </div>
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between text-sm text-slate-200">
              <span>Длина пароля</span>
              <span className="font-semibold">{options.length}</span>
            </div>
            <input
              type="range"
              min={8}
              max={32}
              value={options.length}
              onChange={(event) => setOptions((prev) => ({ ...prev, length: Number(event.target.value) }))}
              className="h-2 w-full cursor-pointer appearance-none rounded-full bg-white/20 accent-cyan-400"
            />
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={options.includeUppercase}
                onChange={(event) =>
                  setOptions((prev) => ({
                    ...prev,
                    includeUppercase: event.target.checked,
                  }))
                }
                className="h-4 w-4 rounded border-white/30 bg-transparent accent-cyan-400"
              />
              Заглавные
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={options.includeNumbers}
                onChange={(event) =>
                  setOptions((prev) => ({
                    ...prev,
                    includeNumbers: event.target.checked,
                  }))
                }
                className="h-4 w-4 rounded border-white/30 bg-transparent accent-cyan-400"
              />
              Цифры
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={options.includeSymbols}
                onChange={(event) =>
                  setOptions((prev) => ({
                    ...prev,
                    includeSymbols: event.target.checked,
                  }))
                }
                className="h-4 w-4 rounded border-white/30 bg-transparent accent-cyan-400"
              />
              Символы
            </label>
          </div>

          <button
            onClick={handleGenerate}
            className="w-full rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 py-3 text-sm font-bold text-slate-950 transition hover:brightness-110"
          >
            Сгенерировать новый пароль
          </button>

          {copied && <p className="text-center text-sm text-emerald-300">Пароль скопирован в буфер обмена</p>}
        </div>
      </section>
    </main>
  );
}
